#include <Arduino.h>
#include <TeensyThreads.h>

#include "sensors.h"

#define BUZZER 4
#define FAIL_FREQ 250
#define SUCCESS_FREQ 3000
#define BEEP_DURATION 500

void setup() {
  Serial.begin(115200);
  initialiseSensors();

  uint32_t start = millis();
  while (true) {
    if (connect()) {
      tone(BUZZER, SUCCESS_FREQ, BEEP_DURATION);
      break;
    }
  }

  tone(BUZZER, SUCCESS_FREQ, BEEP_DURATION);
}

uint32_t p_id = 1;
void loop() {
  updateSensorData(p_id);

  saveData();
  sendData();

  if (findPhase() == 4) {
    static uint32_t lastBeat = millis();
    if (millis() - lastBeat >= 2000) {
      lastBeat = millis();
      tone(BUZZER, 4000, (3/2)*BEEP_DURATION);
    }
  }

  p_id++;
}
