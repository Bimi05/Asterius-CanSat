#include <Arduino.h>

#include "sensor.h"
#include "misc.h"

#define BUZZER 4
#define FAIL_FREQ 250
#define SUCCESS_FREQ 3000
#define BEEP_DURATION 500

#define RFM_FREQUENCY 433.2F


BME680 BME;
BNO085 BNO;
UltimateGPS GPS;
SDCardModule SDCard;
RFM9x RFM(RFM_FREQUENCY);

uint32_t bootTime;
uint32_t p_id = 1;

bool detached = false;
uint32_t lastBeat = millis();


void setup() {
  Serial.begin(9600);

  BME.init();
  BNO.init();
  GPS.init();
  RFM.init();

  bootTime = millis();

  tone(BUZZER, SUCCESS_FREQ, BEEP_DURATION*2);
  delay(BEEP_DURATION*4);


  while (true) {
    static uint32_t lastSent = millis();
    if ((millis() - lastSent) >= 10000) {
      char buffer[] = "Asterius:Pairing requested. [S->M]";
      char* request = process(1, buffer, 1);
      RFM.send(request);
    }

    char received[250];
    RFM.receive(received, 45000);
    char* handshake = process(2, received, 1);

    if (strstr(handshake, "Pairing success") != NULL) {
      tone(BUZZER, 5000, BEEP_DURATION);
      break;
    }
  }
}


void loop() {
  char data[250];

  BME.read();
  BNO.read();
  GPS.read();

  float time = (float) ((millis()-bootTime) / 1000.0F);
  uint8_t len = snprintf(data, 250, "Asterius:%li %.01f %.02f %.02f %.02f %.06f %.06f %.03f %.03f [S->M]", p_id, time, BME.temp, BME.pres, BME.hum, GPS.lat, GPS.lon, BNO.mag, BNO.grav);

  SDCard.save(data);

  char* packet = process(1, data, 1);
  RFM.send(packet, len);

  float altitude = 44330.0F * (1.0F - pow((BME.pres / BME.gpres), 0.1903F));
  uint8_t phase = findPhase(altitude);

  if (phase == 4) {
    if (millis() - lastBeat >= 2000) {
      lastBeat = millis();
      tone(BUZZER, 4000, (3/2)*BEEP_DURATION); //* 4000 Hz is pretty sharp and easy to hear
    }
  }

  p_id++;
}