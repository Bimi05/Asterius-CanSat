#include <Arduino.h>
#include <TeensyThreads.h>

#include "sensors.h"

#define BUZZER 4

void setup() {
  Serial.begin(115200);
  while (!Serial); //* comment out when serial isn't needed

  if (!initialiseSensors()) {
    Serial.println("Something went wrong with the initialisation. Check wirings and addresses.");
    return;
  }

  Serial.println("Sensors initialised. Beginning pairing with Master...");

  uint32_t start = millis();
  while (true) {
    if (connect()) {
      Serial.println("Established connection with Master!");
      break;
    }

    if (millis()-start >= 5*60*1000) {
      break;
    }
  }

  Serial.println("Ready!");
}

uint32_t p_id = 1;
void loop() {
  updateSensorData(p_id);

  saveData();
  sendData();

  if (findPhase() == 4) {
    static uint32_t lastBeat = millis();
    if (millis() - lastBeat >= 2000) {
      lastBeat = millis();
      tone(BUZZER, 3000, 500);
    }
  }

  p_id++;
}
